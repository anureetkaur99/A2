package com.mycompany.a2;
import com.codename1.charts.models.Point;

public abstract class Movable extends GameObject{

	//instance variables, heading needs to accessed by steerable objects
	private int speed;
	protected int heading;
	
//	public Movable() { }
	//constructor
	public Movable(int size, int r, int g, int b, Point location, int speed, int heading) {
		super(size, r, g, b, location);
		this.speed = speed;
		this.heading = heading;
	}

	//the move method
	public void move() {
		//convert the heading and new coordinates for the speed
		float convert = (float) Math.toRadians(90 - heading);
		float deltaY = (float) Math.sin(convert) * speed;
		float deltaX = (float) Math.cos(convert) * speed;
		float newY = this.getLocation().getX() + deltaY;
		float newX = this.getLocation().getY() + deltaX;
		
		//create new location based on the above heading and speed
		Point newLocation = new Point(newX, newY);
		this.setLocation(newLocation);
	}
	
	//getter methods
	public int getSpeed() {
		return this.speed;
	}
	
	//setter method
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	public String toString() {
		return super.toString() + " Speed: " + this.speed + " Heading: " + this.heading;
	}
}
