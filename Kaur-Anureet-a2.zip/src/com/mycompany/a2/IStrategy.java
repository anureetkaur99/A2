package com.mycompany.a2;

import com.codename1.charts.models.Point;

public interface IStrategy {
	public void setStrategy(String strategy);
	public Point invokeStrategy(Point currLocation, Point newLocation);
}
