package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class CollideBaseCommand extends Command{
	private GameWorld gw;
	public CollideBaseCommand(GameWorld gw) {
		super("Collide with Base");
		this.gw = gw;
	}
	
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.baseCollide();
	}
}