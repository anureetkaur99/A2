package com.mycompany.a2;

import com.codename1.charts.models.Point;

public class DirectStrategy implements IStrategy{

	private String currStrategy;
	@Override
	public void setStrategy(String strategy) {
		currStrategy = "Direct";
	}

	@Override
	public Point invokeStrategy(Point currLocation, Point newLocation) {
		if (newLocation.getX() > currLocation.getX())
			currLocation.setX(currLocation.getX() + 2);
		else
			currLocation.setX(currLocation.getX() - 2);
		if (newLocation.getY() > currLocation.getY())
			currLocation.setY(currLocation.getY() + 2);
		else
			currLocation.setY(currLocation.getY() - 2);
		return currLocation;
	}

}
