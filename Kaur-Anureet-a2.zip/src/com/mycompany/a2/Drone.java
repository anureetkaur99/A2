package com.mycompany.a2;

import java.util.Random;

import com.codename1.charts.models.Point;

public class Drone extends Movable {

	private static Random rand = new Random();

	// constuctor
	public Drone(int size, int r, int g, int b, Point location, int speed, int heading) {
		super(size, r, g, b, location, speed, heading);
	}

	// not allowed to set the color
	@Override
	public void setColor(int r, int g, int b) {
	}

	@Override
	public void move() {
		// randomly add or subtract 5 to heading
		Random rand = new Random();
		int droneHeading = heading + (rand.nextInt(10) - 5);

		// convert the heading and new coordinates for the speed
		float convert = (float) Math.toRadians(90 - droneHeading);
		float deltaY = (float) Math.sin(convert) * this.getSpeed();
		float deltaX = (float) Math.cos(convert) * this.getSpeed();
		float newY = this.getLocation().getX() + deltaY;
		float newX = this.getLocation().getY() + deltaX;

		// if within bounds, create new location based on the above heading and speed
		if (newX <= 1000 || newY <= 1000 || newX >= 0 || newY >= 0) {
			Point newLocation = new Point(newX, newY);
			this.setLocation(newLocation);
		} else {
			// else if their center hit the side, they change heading bring it back into the
			// bounds
			float boundX = this.getLocation().getX() - deltaX;
			float boundY = this.getLocation().getY() - deltaY;
			Point newLocation = new Point(boundX, boundY);
			this.setLocation(newLocation);
		}
	}

	public String toString() {
		return "Drone: " + super.toString();
	}
}
