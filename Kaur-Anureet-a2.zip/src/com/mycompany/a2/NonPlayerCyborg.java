package com.mycompany.a2;

import com.codename1.charts.models.Point;

public class NonPlayerCyborg extends Cyborg{
	
	private IStrategy currStrategy;

	public NonPlayerCyborg(int size, int r, int g, int b, Point location, int speed, int heading, int steerDirection,
			int maxSpeed, int energyLevel, int energyConsumptionRate, int damageLevel, int maxDamage, int lastBaseReached, IStrategy currStrategy) {
		
		super(size, r, g, b, location, speed, heading, steerDirection, maxSpeed, energyLevel, energyConsumptionRate,
				damageLevel, maxDamage, lastBaseReached);
		this.currStrategy = currStrategy;
	}
	
	public void switchStrategy(IStrategy strategy) {
		currStrategy = strategy;
	}

	public IStrategy getCurrStrategy() {
		return this.currStrategy;
	}
	
	public String toString() {
		return "Non-Player " + super.toString() + " Strategy: " + currStrategy;
	}
}
