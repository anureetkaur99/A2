package com.mycompany.a2;

import com.codename1.charts.models.Point;

public class PlayerCyborg extends Cyborg {

	// maintain a single global reference to the player cyborg
	private static PlayerCyborg playerCyborg;
	private static Point baseOneLocate = new Point(1,2);
	
	// ensure that no one can create a player cyborg directly
	// private constructor restricted for this class itself	
	private PlayerCyborg() {
		super(40, 255, 0, 0, baseOneLocate, 0, 0, 0, 40, 20, 5, 0, 20, 1);
	}

	// provide access to the instance of Player Cyborg, creating it if necessary
	public static PlayerCyborg getPlayerCyborg() {
		if (playerCyborg == null)
			playerCyborg = new PlayerCyborg();
		return playerCyborg;
	}

	public String toString() {
		return "Player " + super.toString();
	}
}
