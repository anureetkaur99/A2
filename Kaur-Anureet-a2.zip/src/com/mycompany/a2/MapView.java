package com.mycompany.a2;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
public class MapView extends Container implements Observer{
	

	public MapView() {
		setLayout(new FlowLayout());
		getAllStyles().setBorder(Border.createLineBorder(3, ColorUtil.rgb(255, 0, 0)));
	}
	
	//generate the location of all objects in the game world
	public void update (Observable o, Object arg) {
		if (o instanceof GameWorld) {
			GameWorld gw = (GameWorld) o;
			IIterator it = gw.getCollection().getIterator();
			while (it.hasNext()) {
				System.out.println(it.getNext().toString());
			}
			System.out.println();
		}
	}
}
