package com.mycompany.a2;
import com.codename1.charts.models.Point;

public abstract class Fixed extends GameObject{

	//constructor
	public Fixed(int size, int r, int g, int b, Point location) {
		super(size, r, g, b, location);
	}

	//not allowed to change the location
	@Override
	public void setLocation(Point location) {}

	public String toString() {
		return super.toString();
	}
}
