package com.mycompany.a2;

import com.codename1.charts.models.Point;

public class Base extends Fixed{

	//instance variables
	private int sequenceNumber;
	
	//constructor
	public Base(int size, int r, int g, int b, Point location, int sequenceNumber) {
		super(size, r, g, b, location);
		this.sequenceNumber = sequenceNumber;
	}
	
	//getter method
	public int getSeqNumber() {
		return this.sequenceNumber;
	}

	//not allowed to change the color
	@Override
	public void setColor(int r, int g, int b) {}
	
	//toString method
	public String toString() {
		return "Base: " + super.toString() + " SequenceNum: " + this.sequenceNumber;
	}
	

}
