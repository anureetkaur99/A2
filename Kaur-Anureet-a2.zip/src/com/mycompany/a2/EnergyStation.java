package com.mycompany.a2;
import java.util.Random;

import com.codename1.charts.models.Point;

public class EnergyStation extends Fixed{

	//instance variable
	private int capacity;
	
	//constructor
	public EnergyStation(int size, int r, int g, int b, Point location, int capacity) {
		super(size, r, g, b, location);
		this.capacity = capacity;
	}

	//getter method
	public int getCapacity() {
		return this.capacity;
	}
	
	//setter method
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	//toString method
	public String toString() {
		return "EnergyStation: " + super.toString() + "Capacity: " + this.capacity;
	}

}
