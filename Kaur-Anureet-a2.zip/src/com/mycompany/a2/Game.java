package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.CheckBox;
import com.codename1.ui.ComboBox;
import com.codename1.ui.Command;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;
import java.lang.String;

public class Game extends Form {

	// instance variables
	private GameWorld gw;
	private MapView mv; // new in A2
	private ScoreView sv; // new in A2

	// constructor
	public Game() {
		// observable GameWorld
		gw = new GameWorld(); // create "Observable" GameWorld

		// Add observers and register them
		mv = new MapView();
		sv = new ScoreView();
		gw.addObserver(mv);
		gw.addObserver(sv);
		myForm();
		this.show();
		gw.setWidth(mv.getWidth());
		gw.setHeight(mv.getHeight());
		gw.init();
		this.show();
	}

	private void myForm() {
		setLayout(new BorderLayout());
		// Top Tool bar (part of North area)
		Toolbar myToolbar = new Toolbar();
		setToolbar(myToolbar);

		// instantiate commands
		AccelerateCommand accel = new AccelerateCommand(gw);
		BrakeCommand brak = new BrakeCommand(gw);
		LeftCommand le = new LeftCommand(gw);
		RightCommand ri = new RightCommand(gw);
		CollideNpcCommand collideN = new CollideNpcCommand(gw);
		CollideBaseCommand collideB = new CollideBaseCommand(gw);
		CollideEnergyCommand collideE = new CollideEnergyCommand(gw);
		CollideDroneCommand collideD = new CollideDroneCommand(gw);
		TickCommand tic = new TickCommand(gw);
		ExitCommand exi = new ExitCommand();
		ChangeStrategyCommand change = new ChangeStrategyCommand(gw);
		SoundCommand soun = new SoundCommand(gw, myToolbar);
		AboutCommand abou = new AboutCommand();
		HelpCommand hel = new HelpCommand();

		// keybinding
		addKeyListener('a', accel);
		addKeyListener('b', brak);
		addKeyListener('l', le);
		addKeyListener('r', ri);
		addKeyListener('e', collideE);
		addKeyListener('g', collideD);
		addKeyListener('t', tic);

		// NORTH
		// Title
		Label title = new Label("Sili Challenge");
		title.getAllStyles().setFgColor(ColorUtil.BLACK);
		myToolbar.setTitleComponent(title);
		Toolbar.setOnTopSideMenu(false);
		// Side Menu Accelerate Button
		CustomButton sideAccel = new CustomButton("Accelerate", accel);
		myToolbar.addComponentToSideMenu(sideAccel);
		// Side Menu Sound Button
		CheckBox sound = new CheckBox("Sound");
		sound.getAllStyles().setBgColor(ColorUtil.GRAY);
		sound.getAllStyles().setBgTransparency(255);
		sound.setCommand(soun);
		myToolbar.addComponentToSideMenu(sound);
		// Side Menu About Button
		CustomButton about = new CustomButton("About", abou);
		myToolbar.addComponentToSideMenu(about);
		// Side Menu Exit Button
		CustomButton exit = new CustomButton("Exit", exi);
		myToolbar.addComponentToSideMenu(exit);
		// Help Button on Right
		HelpCommand help = new HelpCommand();
		myToolbar.addCommandToRightBar(help);;
		add(BorderLayout.NORTH, sv);
		this.show();
		// CENTER
		add(BorderLayout.CENTER, mv);

		// WEST
		// Container Designing
		Container leftContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		leftContainer.getAllStyles().setPadding(Component.TOP, 50);
		leftContainer.getAllStyles().setPadding(Component.BOTTOM, 50);
		leftContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.BLACK));
		// Accelerate Button
		CustomButton accelerate = new CustomButton("Accelerate", accel);
		leftContainer.add(accelerate);
		// Left Button
		CustomButton left = new CustomButton("Left", le);
		leftContainer.add(left);
		// Change Strategies Button
		CustomButton changeStrategies = new CustomButton("Change Strategies", change);
		leftContainer.add(changeStrategies);
		add(BorderLayout.WEST, leftContainer);

		// EAST container with Box Layout
		// Container Designing
		Container rightContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		rightContainer.getAllStyles().setPadding(Component.TOP, 50);
		rightContainer.getAllStyles().setPadding(Component.BOTTOM, 50);
		rightContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.BLACK));
		// Brake Button
		CustomButton brake = new CustomButton("Brake", brak);
		rightContainer.add(brake);
		// Right Button
		CustomButton right = new CustomButton("Right", ri);
		rightContainer.add(right);
		add(BorderLayout.EAST, rightContainer);

		// SOUTH container with Flow Layout
		// Container Designing
		Container bottomContainer = new Container(new FlowLayout(Component.CENTER));
		bottomContainer.getAllStyles().setPadding(Component.LEFT, 10);
		bottomContainer.getAllStyles().setPadding(Component.RIGHT, 10);
		bottomContainer.getAllStyles().setBorder(Border.createLineBorder(4, ColorUtil.BLACK));
		// Cyborg Collide Button
		CustomButton npcCollide = new CustomButton("Collide with NPC", collideN);
		bottomContainer.add(npcCollide);
		// Base Collide Button
		CustomButton baseCollide = new CustomButton("Collide with Base", collideB);
		bottomContainer.add(baseCollide);
		// Energy Station Collide Button
		CustomButton energyCollide = new CustomButton("Collide with Energy Station", collideE);
		bottomContainer.add(energyCollide);
		// Drone Collide Button
		CustomButton droneCollide = new CustomButton("Collide with Drone", collideD);
		bottomContainer.add(droneCollide);
		// Tick Button
		CustomButton tick = new CustomButton("Tick", tic);
		bottomContainer.add(tick);
		add(BorderLayout.SOUTH, bottomContainer);

		this.show();
	}
}
