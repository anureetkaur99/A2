package com.mycompany.a2;
import java.util.Observable;

import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;

public class ScoreView extends Container implements Observer {

	private Label time, lives, lastBaseReached, energyLevel, damageLevel, sound;
	public ScoreView() {
		//Adding the labels done in the constructor of the ScoreView
		setLayout(new FlowLayout(Component.CENTER));
		time = new Label();
		time.getAllStyles().setFgColor(ColorUtil.BLUE);
		add(time);
		lives = new Label();
		lives.getAllStyles().setFgColor(ColorUtil.BLUE);
		add(lives);
		lastBaseReached = new Label();
		lastBaseReached.getAllStyles().setFgColor(ColorUtil.BLUE);
		add(lastBaseReached);
		energyLevel = new Label();
		energyLevel.getAllStyles().setFgColor(ColorUtil.BLUE);
		add(energyLevel);
		damageLevel = new Label();
		damageLevel.getAllStyles().setFgColor(ColorUtil.BLUE);
		add(damageLevel);
		sound = new Label();
		sound.getAllStyles().setFgColor(ColorUtil.BLUE);
		add(sound);
		
		//Add padding to all Labels
		time.getAllStyles().setPaddingUnit(Style.UNIT_TYPE_DIPS);
		time.getAllStyles().setPadding(3,3,3,3);
		time.getAllStyles().setMargin(RIGHT, 3);
		
		lives.getAllStyles().setPaddingUnit(Style.UNIT_TYPE_DIPS);
		lives.getAllStyles().setPadding(3,3,3,3);
		lives.getAllStyles().setMargin(RIGHT, 3);
		
		lastBaseReached.getAllStyles().setPaddingUnit(Style.UNIT_TYPE_DIPS);
		lastBaseReached.getAllStyles().setPadding(3,3,3,3);
		lastBaseReached.getAllStyles().setMargin(RIGHT, 3);
		
		energyLevel.getAllStyles().setPaddingUnit(Style.UNIT_TYPE_DIPS);
		energyLevel.getAllStyles().setPadding(3,3,3,3);
		energyLevel.getAllStyles().setMargin(RIGHT, 3);
		
		damageLevel.getAllStyles().setPaddingUnit(Style.UNIT_TYPE_DIPS);
		damageLevel.getAllStyles().setPadding(3,3,3,3);
		damageLevel.getAllStyles().setMargin(RIGHT, 3);
		
		sound.getAllStyles().setPaddingUnit(Style.UNIT_TYPE_DIPS);
		sound.getAllStyles().setPadding(3,3,3,3);
		sound.getAllStyles().setMargin(RIGHT, 3);
	}
	
	public void update (Observable o, Object arg) {
		if (o instanceof GameWorld) {
			GameWorld ob = (GameWorld) o;
			String soundVal = (ob.getSound()) ? "ON" : "OFF";
			time.setText("Time: " + ob.getClock());
			lives.setText("Lives left: " + ob.getLives());
			lastBaseReached.setText("Player Last Base Reached: " + PlayerCyborg.getPlayerCyborg().getLastBaseReached());
			energyLevel.setText("Player Energy Level: " + PlayerCyborg.getPlayerCyborg().getEnergyLevel());
			damageLevel.setText("Player Damage Level: " + PlayerCyborg.getPlayerCyborg().getDamageLevel());
			sound.setText("Sound: " + soundVal);
		}
	}
}
