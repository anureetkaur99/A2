package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;

public class SoundCommand extends Command {
	private GameWorld gw;
	private Toolbar toolbar;
	
	public SoundCommand(GameWorld gw, Toolbar toolbar) {
		super("Sound");
		this.gw = gw;
		this.toolbar = toolbar;
	}
	
	public void actionPerformed(ActionEvent evt) {
		gw.toggleSound();
		toolbar.closeSideMenu();
	}
}
