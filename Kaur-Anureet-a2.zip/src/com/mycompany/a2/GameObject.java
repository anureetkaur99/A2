package com.mycompany.a2;

import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public abstract class GameObject {

	//instance variables
	private int size, color;
	private Point location;
	
//	public GameObject() { }
	//constructor
	public GameObject(int size, int r, int g, int b, Point location) {
		this.size = size;
		this.color = ColorUtil.rgb(r, g, b);
		this.location = location;
	}
	
	//getter methods
	public int getSize() {
		return this.size;
	}
	
	public int getColor() {
		return this.color;
	}
	
	public Point getLocation() {
		return this.location;
	}
	
	//setter methods, cannot set size 
	public void setColor(int r, int g, int b) {
		this.color = ColorUtil.rgb(r, g, b);
	}
	
	public void setLocation(Point location) {
		this.location = location;
	}

	public String toString() {
		return "Size: " + this.size + " Color: " + this.color + " Location: (" + this.location.getX() + ", " + this.location.getY() + ") ";
	}
}
