package com.mycompany.a2;

import java.util.ArrayList;
import java.util.Random;
import com.codename1.charts.models.Point;
import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.TextField;

import java.util.Observable;

public class GameWorld extends Observable {

	// instance variables
	private GameObjectCollection objectList;
	int width, height, lives, clock;
	boolean sound;
	PlayerCyborg player;

	// constructor
	public GameWorld() {
		this.lives = 3;
		this.clock = 0;
		this.sound = false;
	}

	public void init() {
		Random rand = new Random();
		// initializing an empty arrayList so that when we call it multiple times, the
		// objectList from attempt 1, don't get concatenated
		objectList = new GameObjectCollection();

		// construct 4 bases;
		Point baseOneLocate = new Point(1, 2);
		Point baseTwoLocate = new Point(11, 22);
		Point baseThreeLocate = new Point(21, 32);
		Point baseFourLocate = new Point(31, 42);
		Base baseOne = new Base(10, 0, 0, 255, baseOneLocate, 1);
		objectList.add(baseOne);
		Base baseTwo = new Base(10, 0, 0, 255, baseTwoLocate, 2);
		objectList.add(baseTwo);
		Base baseThree = new Base(10, 0, 0, 255, baseThreeLocate, 3);
		objectList.add(baseThree);
		Base baseFour = new Base(10, 0, 0, 255, baseFourLocate, 4);
		objectList.add(baseFour);

		// Singleton pattern: construct 1 Player Cyborg
		player = PlayerCyborg.getPlayerCyborg();
		objectList.add(player);

		// construct 3 NonPlayerCyborgs, location is near 1st base (not exactly 1st
		// base)
		Point npcOneLocate = new Point(5, 6);
		Point npcTwoLocate = new Point(7, 8);
		Point npcThreeLocate = new Point(9, 10);
		NonPlayerCyborg nonPlayer1 = new NonPlayerCyborg(40, 255, 0, 0, npcOneLocate, 0, 0, 0, 40, 20, 5, 0, 100, 1,
				new DirectStrategy());
		objectList.add(nonPlayer1);
		NonPlayerCyborg nonPlayer2 = new NonPlayerCyborg(40, 255, 0, 0, npcTwoLocate, 0, 0, 0, 40, 20, 5, 0, 100, 1,
				new AttackStrategy());
		objectList.add(nonPlayer2);
		NonPlayerCyborg nonPlayer3 = new NonPlayerCyborg(40, 255, 0, 0, npcThreeLocate, 0, 0, 0, 40, 20, 5, 0, 100, 1,
				new DirectStrategy());
		objectList.add(nonPlayer3);

		// construct 2 drones
		for (int i = 1; i <= 2; i++) {
			int size = rand.nextInt(41) + 10;
			int speed = rand.nextInt(5) + 5;
			int heading = rand.nextInt(360);
			Drone drones = new Drone(size, 0, 0, 0, getRandLocation(rand), speed, heading);
			objectList.add(drones);
		}

		// construct 2 energy stations
		for (int i = 1; i <= 2; i++) {
			int size = rand.nextInt(41) + 10;
			EnergyStation eStation = new EnergyStation(size, 0, 255, 0, getRandLocation(rand), size);
			objectList.add(eStation);
		}

		// notify observers of initial state
		this.updateObservers();
	}

	// setters
	public void setWidth(int width) {
		this.width = width;
	}

	public void setHeight(int height) {
		this.height = height;

	}

	public void setClock(int time) {
		clock = time;
	}

	// getters
	public GameObjectCollection getCollection() {
		return objectList;
	}

	public int getWidth(int width) {
		return this.width;
	}

	public int getHeight(int height) {
		return this.height;
	}

	public int getLives() {
		return lives;
	}

	public int getClock() {
		return clock;
	}

	public boolean getSound() {
		return sound;
	}

	public void updateObservers() {
		this.setChanged();
		this.notifyObservers();
	}

	public void toggleSound() {
		this.sound = !this.sound;
		this.updateObservers();
	}

	// the nextFloat function always gives you a number from 0.0 to 1.0 (its always
	// a decimal number). So 1000*0.5 will be 500
	public Point getRandLocation(Random rand) {
		float xLocation = rand.nextFloat() * width;
		float yLocation = rand.nextFloat() * height;
		return new Point(xLocation, yLocation);
	}

	// every time there is a damage or when the level of health is low, the lives
	// are subtracted
	public void damageLives() {
		this.lives--;
		resetDamage();
		if (lives == 0) {
			System.out.println("GAME OVER!");
			System.exit(0);
		}
		init();
	}

	// accelerate the speed of cyborg
	public void accelerate() {
		int newSpeed = player.getSpeed() + 1;
		if (player.getEnergyLevel() != 0 && player.getDamageLevel() != 20 && player.getMaxSpeed() >= newSpeed) {
			player.setSpeed(newSpeed);
		}
		System.out.println(player.getSpeed());
		this.updateObservers();
	}

	// apply brakes to the cyborg
	public void brake() {
		int newSpeed = player.getSpeed() - 1;
		if (player.getMaxSpeed() >= newSpeed && player.getSpeed() != 0)
			player.setSpeed(newSpeed);
		System.out.println(player.getSpeed());
		this.updateObservers();
	}

	// steer left
	public void left() {
		int tempDirection = player.getSteerDirection() - 5;
		if (tempDirection >= -40) {
			player.setSteerDirection(tempDirection);
			player.changeHeading(-5);
			System.out.println(player.heading);
			this.updateObservers();
		}
	}

	// steer right
	public void right() {
		int tempDirection = player.getSteerDirection() + 5;
		if (tempDirection <= 40) {
			player.setSteerDirection(tempDirection);
			player.changeHeading(5);
			System.out.println(player.heading);
			this.updateObservers();
		}
	}
	
	public void changeStrategy() {
		IIterator it = objectList.getIterator();
		while (it.hasNext()) {
			GameObject ob = it.getNext();
			if (ob instanceof NonPlayerCyborg) {
				NonPlayerCyborg nonPlaya = (NonPlayerCyborg) ob;
				if (nonPlaya.getCurrStrategy() instanceof DirectStrategy) {
					nonPlaya.switchStrategy(new AttackStrategy());
				} else 
					nonPlaya.switchStrategy(new DirectStrategy());
			}
		}
	}

	public void resetDamage() {
		player.setDamageLevel(0);
	}
	
	// when cyborg collides with another cyborg
	public void npcCollide() {
		// affect on player cyborg
		player.damageByCyborg();
		int affectColor = player.getDamageLevel() * 10;
		player.setColor(155 + affectColor, 0, 0);
		if (player.getDamageLevel() >= player.getMaxDamage())
			damageLives();
		System.out.println(player.getDamageLevel());

		// affect on non player cyborg
		IIterator it = objectList.getIterator();
		while (it.hasNext()) {
			GameObject ob = it.getNext();
			if (ob instanceof NonPlayerCyborg) {
				NonPlayerCyborg nonPlaya = (NonPlayerCyborg) ob;
				nonPlaya.damageByCyborg(); // NPC also sustain a damage
			}
		}
		this.updateObservers();
	}

	// when cyborg collides with a base
	public void baseCollide() {
		TextField input = new TextField();
		Command ok = new Command("Ok");
		Dialog.show("Enter a number between 1-9: ", input, ok);
		int baseNum = Integer.parseInt(input.getText()); // parse input
		if (baseNum < 1 || baseNum > 9) {
			Dialog.show("Invalid input, try again!", "", "Ok", null);
		} else {
			// if cyborg reaches last base, it wins
			if (baseNum == player.getLastBaseReached() + 1) {
				IIterator it = objectList.getIterator();
				while (it.hasNext()) {
					GameObject ob = it.getNext();
					if (ob instanceof Base) {
						Base b = (Base) ob;
						if (b.getSeqNumber() == baseNum) {
							player.setLastBaseReached(baseNum);
							player.setLocation(b.getLocation());
							if (player.getLastBaseReached() == 4) {
								System.out.println("YOU WON! Total time: " + clock);
								System.exit(0);
							} else if (ob instanceof NonPlayerCyborg) {
								NonPlayerCyborg nonPlaya = (NonPlayerCyborg) ob;
								if (nonPlaya.getLastBaseReached() == 4) {
									System.out.println("Game over, a non-player cyborg wins!");
									System.exit(0);
								}
							}
						}
					}
				}
			}
		}
		System.out.println(player.getLastBaseReached());
		this.updateObservers();
	}

	// cyborg collides with the energy station and its energy increases
	public void energyCollide() {
		Random rand = new Random();
		IIterator it = objectList.getIterator();
		while (it.hasNext()) {
			GameObject ob = it.getNext();
			if (ob instanceof EnergyStation) {
				EnergyStation eStation = (EnergyStation) ob;
				if (eStation.getCapacity() > 0) {
					// add energy stations capacity to cyborgs energy level
					int newEnergyLevel = player.getEnergyLevel() + eStation.getCapacity();
					player.setEnergyLevel(newEnergyLevel);
					// set energy level's capacity to 0
					eStation.setCapacity(0);
					// fade stations color to light green
					eStation.setColor(152, 251, 152);
					// make new energy station
					int size = rand.nextInt(40) + 10;
					EnergyStation newStation = new EnergyStation(size, 0, 255, 0, getRandLocation(rand), size);
					objectList.add(newStation);
					break;
				}
			}
		}
		System.out.println(player.getEnergyLevel());
		this.updateObservers();
	}

	// when cyborg collides with drone
	public void droneCollide() {
		player.damageByDrone();
		int affectColor = player.getDamageLevel() * 10;
		player.setColor(155 + affectColor, 0, 0);
		if (player.getDamageLevel() >= player.getMaxDamage())
			damageLives();
		System.out.println(player.getDamageLevel());
		this.updateObservers();
	}

	// tells the game world that the game clock has ticked, every tick moves the
	// movable objects and reduces Cyborg's food level
	public void clockTick() {
		IIterator it = objectList.getIterator();
		while (it.hasNext()) {
			GameObject ob = it.getNext();
			if (ob instanceof Movable) {
				Movable moveIt = (Movable) ob;
				moveIt.move(); //all movable objects move
				if (moveIt instanceof Cyborg) {
					Cyborg playa = (Cyborg) moveIt;
					// update energy level based on energy consumption
					double newEnergy = playa.getEnergyLevel()
							- playa.getEnergyLevel() * (playa.getEnergyConsumptionRate() / 10.0);
					playa.setEnergyLevel((int) newEnergy);
					if (playa.getEnergyLevel() <= 0)
						this.damageLives();
				}
			}
		}
		int newClock = this.getClock() + 1;
		this.setClock(newClock);
		while (it.hasNext()) {
			GameObject ob = it.getNext();
			if (ob instanceof NonPlayerCyborg) {
				NonPlayerCyborg nonPlaya = (NonPlayerCyborg) ob;
				int newBaseReached = nonPlaya.getLastBaseReached() + 1;
				nonPlaya.setLastBaseReached(newBaseReached);
				if (nonPlaya.getCurrStrategy() instanceof DirectStrategy) {
					while (it.hasNext()) {
						GameObject obj = it.getNext();
						if (obj instanceof Base) {
							Base b = (Base) obj;
							if (b.getSeqNumber() == nonPlaya.getLastBaseReached() + 1) {
								nonPlaya.getCurrStrategy().invokeStrategy(nonPlaya.getLocation(), b.getLocation());
							}
						}
					}
				}	
			}
		}
		
		while (it.hasNext()) {
			GameObject ob = it.getNext();
			if (ob instanceof NonPlayerCyborg) {
				NonPlayerCyborg nonPlaya = (NonPlayerCyborg) ob;
				if (nonPlaya.getCurrStrategy() instanceof AttackStrategy) {
					nonPlaya.getCurrStrategy().invokeStrategy(nonPlaya.getLocation(), player.getLocation());
				}	
			}
		}
		this.updateObservers();
	}

	public String toString() {
		return this.objectList + " " + this.width + " " + this.height + " " + this.lives + " " + this.clock + " "
				+ this.sound;
	}

}
