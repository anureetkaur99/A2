package com.mycompany.a2;

public interface ISteerable {
	public void changeHeading(int heading);
}
